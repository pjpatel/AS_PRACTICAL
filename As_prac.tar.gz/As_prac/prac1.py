#!/usr/bin/python
#def main(): 
r = True 
while r: 
	try: 
		n = int(raw_input("please enter your age in years: "))
 		if n<=0: 
			print "UNBORN" 
		elif n>0 and n<=150: 
			print "ALIVE"
		elif n>150:
			print "VAMPIRE" 
		else: print "you hit the Alphabets!" 
	except ValueError:
		print "\n\n Only input number.. \nGood bye..\n\n" 
	r = False 
#if __name__ == '__main__': 
	# main()

