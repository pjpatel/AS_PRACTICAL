def count_consonants(input_string):
	counter = 0
	CONSONANTS = tuple("bcdfghjklmnpqrstvwxzBCDFGHJKLMNPQRSTVWXYZ")
	for letter in input_string:
		if letter.lower() in CONSONANTS or letter.upper() in CONSONANTS:
			counter += 1
	return counter
def main():
	input_string = raw_input("please enter any strings: ")
        print count_consonants(input_string)



if __name__ == '__main__':
	main()
